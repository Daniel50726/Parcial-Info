#include <iostream>
#include <fstream>
#include <string>
#include <stdio.h>

using namespace std;

class usuarios{
    private:
        string nombre;
        string clave;
    public:
        string lectura(string txt);
        string getNombre() const;
        void setNombre(const string &value);
        string getContrasenia() const;
        void setConstrasenia(const string &value);
        bool login(string name, string pasword, string text);
};

string usuarios::getNombre() const
{
    return nombre;
}

void usuarios::setNombre(const string &value)
{
    nombre = value;
}

string usuarios::getContrasenia() const
{
    return clave;
}

void usuarios::setConstrasenia(const string &value)
{
    clave=value;
}



