
#include <usuario.cpp>

int main()
{
    bool login=false;
    string admin="Admin.txt",guardar; //txt donde estan guardados los datos del Admin
    string usuario="Usuario.txt",usu; //txt donde estan guardados los datos de los Usuarios
    string name, pasword;
    usuarios Admin, Cliente;
    char option=' ',optionAdmin=' ', optionUsuario=' ';
    guardar=Admin.lectura(admin); //leemos el txt del Admin
    usu=Cliente.lectura(usuario); //leemos el txt del Cliente

    while(option!='C' and option!='c'){

        cout<<endl;
        cout<<"BIENVENIDO"<<endl;
        cout<<endl;
        cout<<"Que desea hacer?"<<endl;
        cout<<"A - Ingresar como Administrador"<<endl;
        cout<<"B - Ingresar como cliente"<<endl;
        cout<<"C - Salir"<<endl;
        cout<<"Su opcion es: ";
        cin>>option;  //leemos la manera de logearse

        if(option=='A' or option=='a'){
            cin.ignore();
            cout<<"Ingrese su nombre: ";
            getline(cin, name);
            Admin.setNombre(name);

            cout<<"Ingrese su clave: ";
            getline(cin, pasword);
            Admin.setConstrasenia(pasword);

            login = Admin.login(name,pasword,guardar); //comprobamos los datos ingresados

            while(login==true){
                cout<<endl;
                cout<<"A - Mirar inventario"<<endl;
                cout<<"B - Hacer combos"<<endl;
                cout<<"C - Registrar usuario"<<endl;
                cout<<"D - Salir"<<endl;
                cout<<"Su opcion es: ";
                cin>>optionAdmin; //leemos las opciones del Admin
                if(optionAdmin=='A' or optionAdmin=='a'){
                    cout<<"Estamos trabajando en eso"<<endl;
                }
                if(optionAdmin=='B' or optionAdmin=='b'){
                    cout<<"Estamos trabajando en eso"<<endl;
                }
                if(optionAdmin=='C' or optionAdmin=='c'){
                    cout<<"Estamos trabajando en eso"<<endl;
                }
                if(optionAdmin=='D' or optionAdmin=='d'){
                    login=false;
                }
            }

        }

        if(option=='B' or option=='b'){
            cin.ignore();
            cout<<"Ingrese su nombre: ";
            getline(cin,name);
            Cliente.setNombre(name);

            cout<<"Ingrese su clave: ";
            getline(cin,pasword);
            Cliente.setNombre(pasword);

            login=Cliente.login(name,pasword,usu); //comprobamos los datos ingresados

            while(login==true){
                cout<<endl;
                cout<<"A - Mirar tabla de combos"<<endl;
                cout<<"B - Seleccionar combo"<<endl;
                cout<<"C - Salir"<<endl;
                cout<<"Su opcion es: ";
                cin>>optionUsuario; //leemos las opciones del Usuario

                if(optionUsuario=='A' or optionUsuario == 'a'){
                    cout<<"Estamos trabajando en eso"<<endl;
                }
                if(optionUsuario=='B' or optionUsuario == 'b'){
                    cout<<"Estamos trabajando en eso"<<endl;
                }
                if(optionUsuario=='C' or optionUsuario == 'c'){
                    login=false;
                }
            }
        }

    }
}


