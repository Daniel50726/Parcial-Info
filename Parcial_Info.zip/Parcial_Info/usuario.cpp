#include <usuario.h>

string usuarios::lectura(string txt){
    string y;
    ifstream archivo;
    archivo.open(txt,ios::in); //abrimos el archivo en modo lectura

    if(archivo.fail()){
        cout<<"No se pude abrir el programa"<<endl;
    }
    //tenemos en la varieble y todo lo que esta en el archivo
    while(!archivo.eof()){
        getline(archivo,y);
    }
    archivo.close();
    return y;
}

bool usuarios::login(string name, string pasword, string guardar){
     size_t foundNom = guardar.find(name); //Buscamos el nombre en el archivo.txt
     size_t foundPas = guardar.find(pasword);//Buscamos la clave en el archivo.txt
     if(foundNom != string::npos && foundPas != string::npos){
        cout<<endl<<"LOGEADO CON EXITO"<<endl;
        return true; //retornamos true si fue logeado con exito
     }
     else {
         cout<<endl<<"ERROR EN EL USUARIO O CONTRANIA"<<endl;
         return false;
     }
}
