

string lectura(string texto);
